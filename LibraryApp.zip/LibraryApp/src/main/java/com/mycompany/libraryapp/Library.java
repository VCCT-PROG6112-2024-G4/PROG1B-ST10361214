/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.libraryapp;
import java.util.ArrayList;
/**
 *
 * @author lab_services_student
 */
public class Library {
    private ArrayList<Book> books = new ArrayList<>();

    // Add a new book to the library
    public void addBook(Book book) {
        books.add(book);
        System.out.println("Book added successfully.");
    }

    // Remove a book by ID
    public void removeBook(String itemID) {
        for (Book book : books) {
            if (book.getItemID().equals(itemID)) {
                books.remove(book);
                System.out.println("Book removed successfully.");
                return;
            }
        }
        System.out.println("Book not found.");
    }

    // Search for a book by title or author
    public void searchBook(String keyword) {
        for (Book book : books) {
            if (book.getTitle().contains(keyword) || book.getAuthor().contains(keyword)) {
                book.displayItemDetails();
                return;
            }
        }
        System.out.println("Book not found.");
    }

    // Borrow a book by ID
    public void borrowBook(String itemID) {
        for (Book book : books) {
            if (book.getItemID().equals(itemID) && !book.isBorrowed()) {
                book.borrowBook();
                System.out.println("Book borrowed successfully.");
                return;
            }
        }
        System.out.println("Book not available or already borrowed.");
    }

    // Return a borrowed book by ID
    public void returnBook(String itemID) {
        for (Book book : books) {
            if (book.getItemID().equals(itemID) && book.isBorrowed()) {
                book.returnBook();
                System.out.println("Book returned successfully.");
                return;
            }
        }
        System.out.println("Book not found or not borrowed.");
    }

    // Generate report of all books
    public void generateReport() {
        System.out.println("Library Report:");
        for (Book book : books) {
            book.displayItemDetails();
            System.out.println("-----------------------");
        }
    }
}