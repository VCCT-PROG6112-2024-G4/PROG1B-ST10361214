/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.libraryapp;
import java.util.Scanner;
/**
 *
 * @author lab_services_student
 */
public class LibraryApp {

   private static Library library = new Library();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            displayMenu();
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    addNewBook();
                    break;
                case 2:
                    searchForBook();
                    break;
                case 3:
                    borrowBook();
                    break;
                case 4:
                    returnBook();
                    break;
                case 5:
                    removeBook();
                    break;
                case 6:
                    generateReport();
                    break;
                case 7:
                    System.out.println("Exiting application.");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void displayMenu() {
        System.out.println("\nLibrary Management System:");
        System.out.println("1. Add New Book");
        System.out.println("2. Search for Book");
        System.out.println("3. Borrow a Book");
        System.out.println("4. Return a Book");
        System.out.println("5. Remove a Book");
        System.out.println("6. Generate Report");
        System.out.println("7. Exit");
        System.out.print("Enter your choice: ");
    }

    private static void addNewBook() {
        System.out.print("Enter Book ID: ");
        String itemID = scanner.nextLine();
        System.out.print("Enter Book Title: ");
        String title = scanner.nextLine();
        System.out.print("Enter Book Author: ");
        String author = scanner.nextLine();

        library.addBook(new Book(itemID, title, author));
    }

    private static void searchForBook() {
        System.out.print("Enter title or author to search: ");
        String keyword = scanner.nextLine();
        library.searchBook(keyword);
    }

    private static void borrowBook() {
        System.out.print("Enter Book ID to borrow: ");
        String itemID = scanner.nextLine();
        library.borrowBook(itemID);
    }

    private static void returnBook() {
        System.out.print("Enter Book ID to return: ");
        String itemID = scanner.nextLine();
        library.returnBook(itemID);
    }

    private static void removeBook() {
        System.out.print("Enter Book ID to remove: ");
        String itemID = scanner.nextLine();
        library.removeBook(itemID);
    }

    private static void generateReport() {
        library.generateReport();
    }
}










