/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.libraryapp;

/**
 *
 * @author lab_services_student
 */
public class Book extends Item {
    private boolean isBorrowed;

    public Book(String itemID, String title, String author) {
        super(itemID, title, author);
        this.isBorrowed = false;
    }

    // Methods to borrow and return the book
    public void borrowBook() {
        this.isBorrowed = true;
    }

    public void returnBook() {
        this.isBorrowed = false;
    }

    // Getter for isBorrowed
    public boolean isBorrowed() {
        return isBorrowed;
    }

    @Override
    public void displayItemDetails() {
        super.displayItemDetails();
        System.out.println("Borrowed: " + (isBorrowed ? "Yes" : "No"));
    }
}
