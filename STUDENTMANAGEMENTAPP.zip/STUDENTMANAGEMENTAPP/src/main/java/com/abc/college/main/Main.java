/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.abc.college.main;

import java.util.Scanner;

/**
 *
 * @author Kal
 */

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean running = true;

        while (running) {
            System.out.println("STUDENT MANAGEMENT APPLICATION");
            System.out.println("Enter (1) to launch menu or any other key to exit");
            String choice = scanner.nextLine();

            if (!choice.equals("1")) {
                running = false;
                break;
            }

            System.out.println("Please select one of the following menu items:");
            System.out.println("(1) Capture a new student.");
            System.out.println("(2) Search for a student.");
            System.out.println("(3) Delete a student.");
            System.out.println("(4) Print student report.");
            System.out.println("(5) Exit Application.");
            choice = scanner.nextLine();

            switch (choice) {
                case "1":
                    captureNewStudent(scanner);
                    break;case "2":
                    searchStudent(scanner);
                    break;
                case "3":
                    deleteStudent(scanner);
                    break;
                case "4":
                    printStudentReport();
                    break;
                case "5":
                    running = false;
                    break;
                default:
                    System.out.println("Invalid option, please try again.");
            }
        }

        System.out.println("Exiting Application. Goodbye!");
        scanner.close();
    }

    private static void captureNewStudent(Scanner scanner) {
        System.out.println("CAPTURE A NEW STUDENT");

        System.out.print("Enter the student ID: ");
        String id = scanner.nextLine();
        
System.out.print("Enter the student name: ");
        String name = scanner.nextLine();

        int age;
        while (true) {
            System.out.print("Enter the student age: ");
            try {
                age = Integer.parseInt(scanner.nextLine());
                if (age < 16) {
                    System.out.println("You have entered an incorrect student age!!! Please re-enter the student age >>");
                } else {
                    break;
                }
            } catch (NumberFormatException e) {
                System.out.println("You have entered an incorrect student age!!! Please re-enter the student age >>");
            }
        }

        System.out.print("Enter the student email: ");
        String email = scanner.nextLine();

        System.out.print("Enter the student course: ");
        String course = scanner.nextLine();

        Student.SaveStudent(id, name, age, email, course);
        System.out.println("Enter (1) to launch menu or any other key to exit");
        scanner.nextLine(); // To pause for user input
    }private static void searchStudent(Scanner scanner) {
        System.out.print("Enter the student ID to search: ");
        String id = scanner.nextLine();
        Student.SearchStudent(id);
        System.out.println("Enter (1) to launch menu or any other key to exit");
        scanner.nextLine(); // To pause for user input
    }

    private static void deleteStudent(Scanner scanner) {
        System.out.print("Enter the student ID to delete: ");
        String id = scanner.nextLine();
        System.out.print("Are you sure you want to delete student " + id + " from the system? Yes (y) to delete: ");
        String confirm = scanner.nextLine();
        if (confirm.equalsIgnoreCase("y")) {
            Student.DeleteStudent(id);
        } else {
            System.out.println("Deletion cancelled.");
        }
        System.out.println("Enter (1) to launch menu or any other key to exit");
        scanner.nextLine(); // To pause for user input
    }

    private static void printStudentReport() {
        System.out.println("STUDENT REPORT");
        for (Student student : Student.getStudents()) {
            System.out.println("STUDENT ID: " + student.getId());
            System.out.println("STUDENT NAME: " + student.getName());
            System.out.println("STUDENT AGE: " + student.getAge());
            System.out.println(student.getEmail() + "STUDENT EMAIL: ");
                    System.out.println("STUDENT COURSE: " + student.getCourse());
            System.out.println();
        }
        System.out.println("Enter (1) to launch menu or any other key to exit");
    }
}
