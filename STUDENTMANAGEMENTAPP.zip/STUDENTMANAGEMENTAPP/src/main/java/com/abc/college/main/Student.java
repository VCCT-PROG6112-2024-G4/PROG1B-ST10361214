/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.abc.college.main;

import java.util.ArrayList;

/**
 *
 * @author Kal
 */
public class Student {
    private final String id;
    private final String name;
    private final int age;
    private final String email;
    private final String course;

    private static ArrayList<Student> studentList = new ArrayList<>();

    public Student(String id, String name, int age, String email, String course) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.email = email;
        this.course = course;
    }
    
public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getEmail() {
        return email;
    }

    public String getCourse() {
        return course;
    }

    public static void SaveStudent(String id, String name, int age, String email, String course) {
        Student student = new Student(id, name, age, email, course);
        studentList.add(student);
        System.out.println("Student details have been successfully saved.");
    }

    public static void SearchStudent(String id) {
        for (Student student : studentList) {
            if (student.id.equals(id)) {
                System.out.println("STUDENT ID: " + student.id);
                System.out.println("STUDENT NAME: " + student.name);
                System.out.println("STUDENT AGE: " + student.age);
                System.out.println("STUDENT EMAIL: " + student.email);
                System.out.println("STUDENT COURSE: " + student.course);
                return;
            }
        }
        System.out.println("Student with Student ID: " + id + " was not found!");
    }

    public static void DeleteStudent(String id) {
        for (Student student : studentList) {
            if (student.id.equals(id)) {
                studentList.remove(student);
                System.out.println("Student with Student ID: " + id + " WAS deleted!");
                return;
            }
        }
        System.out.println("Student with Student ID: " + id + " was not found!");
    }

    public static ArrayList<Student> getStudents() {
        return studentList;
    }

    public static void clearStudents() {
        studentList.clear();
    }
}